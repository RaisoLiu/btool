# Installation

install
```
pip install git+https://github.com/RaisoLiu/btool.git
```

build
```
python setup.py sdist bdist_wheel
```
