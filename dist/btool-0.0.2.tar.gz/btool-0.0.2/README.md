# Installation
```
pip install git+https://github.com/RaisoLiu/btool.git
```